import { test } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import fs from 'fs';

const BASE = 'https://scoms-erp-main.vercel.app';
const ROLE = process.env.ROLE || 'user';
const OUT = `crawl-output/${ROLE}`;
const MAX_PAGES = 50;
test.setTimeout(15 * 60 * 1000);
test.use({ actionTimeout: 30000 });

test(`full site crawl: ${ROLE}`, async ({ page }) => {
  fs.mkdirSync(OUT, { recursive: true });

  // Login diagnostics
  page.on('response', r => {
    if (r.request().method() === 'POST') console.log('POST', r.status(), r.url());
  });
  page.on('requestfailed', r => console.log('FAILED', r.url(), r.failure()?.errorText));
  page.on('console', m => { if (m.type() === 'error') console.log('CONSOLE', m.text()); });

  // Log in through the portal tile
  await page.goto(`${BASE}/login`);
  let tile = page.getByText(process.env.PORTAL!, { exact: true });
  if ((await tile.count()) === 0) tile = page.getByText(process.env.PORTAL!);
  await tile.first().click();
  await page.locator('input').first().fill(process.env.TEST_USER!);
  await page.locator('input[type="password"]').fill(process.env.TEST_PASSWORD!);
  const t0Login = Date.now();
  await page.getByRole('button', { name: /login|sign in/i }).click();
  await page.waitForURL(u => !u.pathname.includes('/login'), { timeout: 60000 });
  console.log('login took ms:', Date.now() - t0Login);
  await page.waitForLoadState('networkidle');

  const visited = new Set<string>();
  const queue: string[] = [page.url()];
  const report: any[] = [];

  while (queue.length && visited.size < MAX_PAGES) {
    const url = queue.shift()!;
    if (visited.has(url)) continue;
    visited.add(url);

    const problems: string[] = [];
    const onConsole = (m: any) => { if (m.type() === 'error') problems.push('console: ' + m.text()); };
    const onResponse = (r: any) => { if (r.status() >= 400) problems.push(`${r.status()} ${r.url()}`); };
    page.on('console', onConsole);
    page.on('response', onResponse);

    const t0 = Date.now();
    await page.goto(url, { waitUntil: 'networkidle' });
    const loadMs = Date.now() - t0;

    const axe = await new AxeBuilder({ page }).analyze();
    const name = String(report.length + 1).padStart(2, '0');
    await page.screenshot({ path: `${OUT}/${name}.png`, fullPage: true });

    const links: string[] = await page.$$eval('a[href]', as =>
      as.map(a => (a as HTMLAnchorElement).href));
    for (const l of links) {
      const clean = l.split('#')[0];
      if (clean.startsWith(BASE) && !/logout|signout|delete|remove/i.test(clean)
          && !visited.has(clean)) queue.push(clean);
    }

    page.off('console', onConsole);
    page.off('response', onResponse);

    report.push({
      role: ROLE, url, title: await page.title(), loadMs, problems,
      a11y: axe.violations.map(v => ({ id: v.id, impact: v.impact, nodes: v.nodes.length })),
      screenshot: `${name}.png`,
    });
  }

  fs.writeFileSync(`${OUT}/report.json`, JSON.stringify(report, null, 2));
  console.log(`${ROLE}: crawled ${report.length} pages`);
});