import { test, expect } from '@playwright/test';

const URL = 'https://scoms-erp-main.vercel.app/login';

test('login page loads', async ({ page }) => {
  await page.goto(URL);
  await expect(page).toHaveTitle(/scoms/i);
  await expect(page.locator('input[type="password"]')).toBeVisible();
});

test('wrong password stays on login', async ({ page }) => {
  await page.goto(URL);
  await page.locator('input').first().fill('test@example.com');
  await page.locator('input[type="password"]').fill('wrongpass123');
  await page.getByRole('button', { name: /login|sign in/i }).click();
  await expect(page).toHaveURL(/login/);
});

test('mobile layout works', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(URL);
  await expect(page.locator('input[type="password"]')).toBeVisible();
});