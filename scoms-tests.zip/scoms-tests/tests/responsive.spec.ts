import { test, expect, devices } from '@playwright/test';

const URL = 'https://scoms-erp-main.vercel.app/login';

const sizes = {
  'iPhone 13': devices['iPhone 13'],
  'iPad Mini': devices['iPad Mini'],
  'Desktop': { viewport: { width: 1920, height: 1080 } },
};

for (const [name, config] of Object.entries(sizes)) {
  test(`login form is visible on ${name}`, async ({ browser }) => {
    const context = await browser.newContext(config);
    const page = await context.newPage();
    await page.goto(URL);
    await expect(page.locator('input[type="password"]')).toBeVisible();
    await context.close();
  });
}