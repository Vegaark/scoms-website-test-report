import { test, expect } from '@playwright/test';

test('no console errors or failed requests on login', async ({ page }) => {
  const errors: string[] = [];
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('response', r => { if (r.status() >= 400) errors.push(`${r.status()} ${r.url()}`); });
  await page.goto('https://scoms-erp-main.vercel.app/login');
  await page.waitForLoadState('networkidle');
  expect(errors).toEqual([]);
});