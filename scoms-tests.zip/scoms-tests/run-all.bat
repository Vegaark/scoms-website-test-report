@echo off
cd /d D:\scoms-tests
set "TEST_PASSWORD=Password@123"

set "ROLE=superadmin"
set "PORTAL=Super Admin"
set "TEST_USER=superadmin@scoms.in"
call npx playwright test crawl --project=chromium --reporter=list

set "ROLE=institute-admin"
set "PORTAL=Institute Admin"
set "TEST_USER=admin@dpis-delhi.edu.in"
call npx playwright test crawl --project=chromium --reporter=list

set "ROLE=teacher"
set "PORTAL=Staff & Faculty"
set "TEST_USER=teacher@dpis-delhi.edu.in"
call npx playwright test crawl --project=chromium --reporter=list

set "ROLE=student"
set "PORTAL=Student & Parent"
set "TEST_USER=arun.kumar@student.dpis.edu.in"
call npx playwright test crawl --project=chromium --reporter=list

set "ROLE=parent"
set "PORTAL=Student & Parent"
set "TEST_USER=parent.kumar@dpis.edu.in"
call npx playwright test crawl --project=chromium --reporter=list
